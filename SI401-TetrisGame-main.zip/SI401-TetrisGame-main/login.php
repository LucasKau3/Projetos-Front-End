<?php
// Inicia conexão com o banco de dados
try {
    $conn = new PDO("mysql:host=localhost;dbname=myDB", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
// Se houver algum erro mostra uma mensagem de erro
catch(PDOException $e) {
    echo "A conexão falhou: " . $e->getMessage();
    }



<!DOCTYPE html>

<html lang="pt">

<head>
    <title>Login | Mirror Tetris</title>

    <meta charset="UTF-8">

    <link rel="stylesheet" href="./css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>

<body id="login">
    <section class="login">
        <h1>Faça login ou registre-se</h1>

        <form class="formulario" action="jogo.php" method="POST" autocomplete="off"
            onsubmit="return validateLoginForm()">
            <div class="flutuante">
                <input id="usuario" class="login" type="text" name="usuario" placeholder="Usuário" required>
                <label for="usuario">Usuário</label>
            </div>
            <div class="flutuante">
                <input id="senha" class="login" type="password" name="senha" placeholder="Senha" required>
                <label for="senha">Senha</label>
            </div>

            <button id="botaologin" type="submit">Entrar</button>
            <a id="botao_registrar" href="cadastro.php" title="Registre-se já">Registrar-se</a>
        </form>

        <div class="logologin">
            <img class="logo" src="./images/logo-tetris.png" alt="logo_tetris">
        </div>
    </section>

    <script type="text/javascript" src="./js/form-validation.js"></script>
</body>

</html>
