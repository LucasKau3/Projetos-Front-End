# Docs do projeto:
https://docs.google.com/document/d/1dKvbeEMCDpblQsy-_cN8gYKAsjDE-0OYTrVZsXMYc_w/edit?usp=sharing

# Projeto Tetris:
**_Projeto desenvolvido pelos seguinte grupo:_**
_Heitor Lopes;
Lucas Kauê;
Ulisses Dias;
Marx Maciel._

**- Instruções de Instalação e Contribuição**

## Instalação Local

Siga estas etapas para instalar e executar o projeto em sua máquina local:

1. **Clone o repositório:**

   ```bash
   git clone https://github.com/LucasKau3/SI401-TetriGame.git
   ```

2. **Navegue até o diretório do projeto:**

   ```bash
   cd SI401-Tetris
   ```

3. **Abra o arquivo `jogo.html` em seu navegador:**

   Basta dar um duplo clique no arquivo `jogo.html` ou abri-lo usando um navegador web de sua escolha.

## Modificando o Código

Para contribuir com o projeto e modificar o código, siga estas etapas:

1. **Crie uma branch:**

   Antes de fazer qualquer modificação, crie uma nova branch com um nome descritivo para sua contribuição. Isso ajuda a manter o código principal do projeto limpo.

   ```bash
   git checkout -b nome-da-sua-branch
   ```

   Substitua `nome-da-sua-branch` por um nome que descreva a sua modificação.

2. **Faça suas modificações:**

   Agora, faça as modificações que deseja no código, como adicionar recursos, corrigir bugs, ou qualquer outra melhoria.

3. **Commit suas mudanças:**

   Após fazer as modificações, você deve commitá-las. Certifique-se de incluir uma mensagem de commit descritiva.

   ```bash
   git commit -m "Adicionei novos recursos"
   ```

4. **Envie sua branch para o Github:**

   Envie sua branch para o repositório remoto no Github.

   ```bash
   git push origin nome-da-sua-branch
   ```

5. **Crie um Pull Request:**

   Acesse a página do seu repositório no Github e clique na aba "Pull Requests". Em seguida, clique em "New Pull Request". Selecione sua branch como a branch de origem e a branch principal como a branch de destino. Descreva suas modificações e clique em "Create Pull Request".

6. **Revisão e Merge:**

   Os colaboradores do projeto revisarão suas modificações e, se estiverem corretas e alinhadas com os objetivos do projeto, mesclarão suas alterações na branch principal.

7. **Mantenha sua branch atualizada:**

   Certifique-se de manter sua branch atualizada com as últimas alterações da branch principal, especialmente se a revisão do Pull Request levar algum tempo.

   ```bash
   git pull origin main
   ```

Lembre-se de que é importante seguir as diretrizes do projeto e contribuir de maneira construtiva. Obrigado por contribuir para o nosso projeto!

**Nota:** Certifique-se de que você tenha o Git instalado em seu sistema.
