<!-- Alteração dos dados do ususário -->
<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

// Verifica se a solicitação é do tipo POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Aqui podemos obter os dados do formulário
    $id = $_POST["id"];
    $nomeCompleto = $_POST["nome_completo"];
    $telefone = $_POST["telefone"];
    $email = $_POST["email"];
    $novaSenha = $_POST["nova_senha"];


    // Conexão com o banco de dados
    require_once('db.php');

    // Atualizar os dados do usuário no banco de dados
    $sql = "UPDATE usuarios SET nome_completo='$nomeCompleto', telefone='$telefone', email='$email', senha='$novaSenha' WHERE id=$id";

    // Condição para atualização dos dados
    if ($conn->query($sql) === TRUE) {
        echo "Dados atualizados com sucesso!";
    } else {
        echo "Erro ao atualizar dados: " . $conn->error;
    }

    $conn->close();
}
?>


<!DOCTYPE html>

<html lang="pt">

<head>
    <title>Editar informações | Mirror Tetris</title>

    <meta charset="UTF-8">

    <link rel="stylesheet" href="./css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>

<body id="editar">
    <section class="editar">
        <h1>Edite suas informações</h1>

        <form class="formulario" action="alterardados.php" method="POST" autocomplete="off">
        <form class="formulario" action="alterardados.php" method="POST" autocomplete="off">
    <!-- Campo para o ID um campo oculto para o ID do usuário -->
    <input type="hidden" name="id" value="<?php echo $_SESSION['id']; ?>">


            <div class="flutuante">
                <input id="username" class="editar" type="text" name="username" placeholder="Username" disabled>
                <label for="username">Username</label>
            </div>
            <div class="flutuante">
                <input id="cpf" class="editar" type="text" name="cpf" placeholder="CPF" disabled>
                <label for="cpf">CPF</label>
            </div>
            <div class="flutuante">
                <input id="data_nascimento" class="editar" type="date" name="data_nascimento" disabled>
                <label for="data_nascimento">Data de nascimento</label>
            </div>
            <div class="flutuante">
                <input id="nome_completo" class="editar" type="text" name="nome_completo" placeholder="Nome completo">
                <label for="nome_completo">Nome completo</label>
            </div>
            <div class="flutuante">
                <input id="telefone" class="editar" type="tel" name="telefone" placeholder="Telefone">
                <label for="telefone">Telefone</label>
            </div>
            <div class="flutuante">
                <input id="email" class="editar" type="email" name="email" placeholder="E-mail">
                <label for="email">E-mail</label>
            </div>
            <div class="flutuante">
                <input id="nova_senha" class="editar" type="password" name="nova_senha" placeholder="Nova senha">
                <label for="nova_senha">Nova senha</label>
            </div>
            <div class="flutuante">
                <input id="confirmarnova_senha" class="editar" type="password" name="confirmarnova_senha"
                    placeholder="Nova senha">
                <label for="confirmarnova_senha">Confirmar nova senha</label>
            </div>

            <div id="alinhar">
                <button id="botaosalvar" type="submit" title="Salvar">Salvar alterações</button>
                <a id="botaovoltarjogo" href="jogo.php" title="Voltar">Voltar</a>
            </div>
        </form>

        <div class="logocadastro">
            <img class="logo" src="./images/logo-tetris.png" alt="logo_tetris">
        </div>
    </section>

    <script type="text/javascript" src="./js/form-validation.js"></script>
    <script>validateEditUserInfoForm();</script>

</body>

</html>
