<?php
session_start();
if (!isset($_SESSION['id']))
{
    header("Location: login.php");
}
?>

<!DOCTYPE html>

<html lang="pt">

<head>
    <title>Jogo | Mirror Tetris</title>

    <!-- CSS do Jogo-->
    <link rel="stylesheet" type="text/css" href="./game/style.css">

    <meta charset="UTF-8">

    <link rel="shortcut icon" href="./images/logo-tetris.png" type="image/x-icon">
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>

<body id="jogo">
    <!-- Aviso de GAME OVER -->
    <div id="game-over" style="color: white;">
        <h2>GAME OVER</h2>
        <h3 id="final-score"></h3>
        <h4>Clique para jogar novamente</h4>
    </div>

    <!-- Painel de Info do Jogo -->
    <section class="jogo">
        <div class="barraesquerda">
            <div class="informacoes">
                <p>Tempo: <span id="timerLabel">00:00</span></p>
                <p>Pontuação: <span id="scoreLabel">0</span></p>
                <p>Linhas eliminadas: <span id="rowsLabel">0</span></p>
                <p>Nível: <span id="levelLabel">Muito Fácil</span></p>
                <div>
                    <a id="botaoeditar" href="alterardados.php" title="Edite suas informações">Editar informações</a>
                </div>
                <div>
                    <a id="botao_ranking" href="ranking.php" title="Veja o Ranking Global">Ranking Global</a>
                </div>
                <div>
                    <a id="botao_ranking_pessoal" onclick="hideRankingPessoal()" title="Veja o Ranking Pessoal">Ranking
                        Pessoal</a>
                </div>
                <div>
                    <a id="botaodesconectar" href="login.php" title="Desconecte-se">Desconectar</a>
                </div>
                <img id="controls" src="./images/controls.png" alt="logo_tetris">

            </div>
        </div>


        <!-- Escolha do tamanho do jogo -->
        <div id="boardSizeSelector">
            <p>Tamanho do Mapa:</p>
            <label for="boardSize">Tamanho do Mapa:</label>
            <select id="boardSize">
                <option value="classic">Clássico (10x20)</option>
                <option value="large">Grande (22x44)</option>
            </select>
            <button id="startButton">Iniciar Jogo</button>
        </div>

        <!-- JOGO -->
        <div id="top">
            <div class="canvas-area">
                <canvas id="tetris" width="200" height="400"></canvas>
                <ul class="sidebar group" list-stye-type="none">
                    <li class="next-piece">
                        <h2>Próxima Peça:</h2>
                        <canvas id="nextPiece" width="100" height="100"></canvas>
                    </li>
                    <li class="hold-piece">
                        <h2>Peça Guardada:</h2>
                        <canvas id="holdPiece" width="100" height="100"></canvas>
                    </li>
                </ul>
            </div>
        </div>
        </div>

        <!-- Ranking Pessoal-->
        <div class="rankingpessoal" style="display: none;">
            <p id="rankingpessoal">RANKING PESSOAL</p>
            <p id="nome">José da Silva Bueno Santos Sampaio</p>
            <p id="partidasjogadas">Partidas Jogadas</p>
            <div class="partidas">
                <div class="partida expert">
                    <div class="primeiro">
                        <p class="posicao">1</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">10900 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel expert">Expert 33</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">07:30</p>
                    </div>
                </div>

                <div class="partida expert">
                    <div class="primeiro">
                        <p class="posicao">2</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">1500 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel expert">Expert 2</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">07:30</p>
                    </div>
                </div>

                <div class="partida dificil">
                    <div class="primeiro">
                        <p class="posicao">3</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">1190 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel dificil">Difícil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">05:12</p>
                    </div>
                </div>

                <div class="partida medio">
                    <div class="primeiro">
                        <p class="posicao">4</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">600 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel medio">Médio</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">03:35</p>
                    </div>
                </div>

                <div class="partida facil">
                    <div class="primeiro">
                        <p class="posicao">5</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">300 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel facil">Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">02:00</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>

                <div class="partida muito_facil">
                    <div class="primeiro">
                        <p class="posicao">99</p>
                    </div>
                    <div class="segundo">
                        <p class="pontos">30 pontos</p>
                    </div>
                    <div class="terceiro">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                    <div class="ultimo">
                        <p class="tempo">00:56</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        function hideRankingPessoal() {
            const divRankingPessoal = document.getElementsByClassName("rankingpessoal")[0];
            if (divRankingPessoal.style.display === "none") {
                divRankingPessoal.style.display = "block";
            } else {
                divRankingPessoal.style.display = "none";
            }
        }
    </script>

    <script src="./game/lib/board.js"></script>
    <script src="./game/lib/player.js"></script>
    <script src="./game/lib/tetris.js"></script>
    <script src="./game/lib/main.js"></script>
</body>

</html>
