<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // Aqui obtemos os dados por meio do 'POS'
  $tempo = $_POST['tempo'];
  $pontos = $_POST['pontos'];
  $nivel = $_POST['nivel'];

  // Precisamos fazer a conexão com o banco de dados
  $conn = new mysqli('seu_servidor_mysql', 'seu_usuario_mysql', 'sua_senha_mysql', 'seu_banco_de_dados');

  if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
  }

  // Inserção dos dados na tabela do banco de dados
  $sql = "INSERT INTO tabela_ranking (tempo, pontos, nivel) VALUES ('$tempo', $pontos, '$nivel')";

  if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso no ranking!";
  } else {
    echo "Erro ao inserir dados no ranking: " . $conn->error;
  }

  $conn->close();
} else {
  echo "Método de requisição inválido.";
}
?>
