<?php
// Inicia conexão com o banco de dados
try {
    $conn = new PDO("mysql:host=localhost;dbname=myDB", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
// Se houver algum erro mostra uma mensagem de erro
catch(PDOException $e) {
    echo "A conexão falhou: " . $e->getMessage();
    }

<!DOCTYPE html>

<html lang="pt">

<head>
    <title>Ranking Global | Mirror Tetris</title>

    <meta charset="UTF-8">

    <link rel="stylesheet" href="./css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>

<body id="ranking">
    <section class="ranking_global">
        <div class="ranking">
            <p id="ranking_global">RANKING GLOBAL</p>
            <div class="jogadores">
                <div class="jogador expert">
                    <div class="primeiro">
                        <p class="posicao">1</p>
                    </div>
                    <div class="segundo">
                        <p class="username">jogadornumero1</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">10490 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel expert">Expert 31</p>
                    </div>
                </div>

                <div class="jogador expert">
                    <div class="primeiro">
                        <p class="posicao">2</p>
                    </div>
                    <div class="segundo">
                        <p class="username">johnson&johnson</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">10450 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel expert">Expert 31</p>
                    </div>
                </div>

                <div class="jogador expert">
                    <div class="primeiro">
                        <p class="posicao">3</p>
                    </div>
                    <div class="segundo">
                        <p class="username">jogadorruim</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">9820 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel expert">Expert 29</p>
                    </div>
                </div>

                <div class="jogador expert">
                    <div class="primeiro">
                        <p class="posicao">4</p>
                    </div>
                    <div class="segundo">
                        <p class="username">alberteinstein</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">3500 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel expert">Expert 8</p>
                    </div>
                </div>

                <div class="jogador expert">
                    <div class="primeiro">
                        <p class="posicao">5</p>
                    </div>
                    <div class="segundo">
                        <p class="username">frederick</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">1360 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel expert">Expert 1</p>
                    </div>
                </div>

                <div class="jogador dificil">
                    <div class="primeiro">
                        <p class="posicao">6</p>
                    </div>
                    <div class="segundo">
                        <p class="username">juninho</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">1180 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel dificil">Difícil</p>
                    </div>
                </div>

                <div class="jogador dificil">
                    <div class="primeiro">
                        <p class="posicao">7</p>
                    </div>
                    <div class="segundo">
                        <p class="username">Galvão Bueno</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">960 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel dificil">Difícil</p>
                    </div>
                </div>

                <div class="jogador medio">
                    <div class="primeiro">
                        <p class="posicao">8</p>
                    </div>
                    <div class="segundo">
                        <p class="username">sponsored</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">620 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel medio">Médio</p>
                    </div>
                </div>

                <div class="jogador facil">
                    <div class="primeiro">
                        <p class="posicao">9</p>
                    </div>
                    <div class="segundo">
                        <p class="username">demolish</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">560 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel facil">Fácil</p>
                    </div>
                </div>

                <div class="jogador muito_facil">
                    <div class="primeiro">
                        <p class="posicao">10</p>
                    </div>
                    <div class="segundo">
                        <p class="username">TETRISMAN</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">280 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                </div>

                <p id="suaposicao">SUA POSIÇÃO NO RANKING</p>

                <div class="jogador muito_facil">
                    <div class="primeiro">
                        <p class="posicao">2390</p>
                    </div>
                    <div class="segundo">
                        <p class="username">augustosilva</p>
                    </div>
                    <div class="terceiro">
                        <p class="pontos">10 pontos</p>
                    </div>
                    <div class="ultimo">
                        <p class="nivel muito_facil">Muito Fácil</p>
                    </div>
                </div>
            </div>

            <div class="centralizar">
                <a id="botaovoltarjogo" href="jogo.php" title="Voltar">Voltar</a>
            </div>
        </div>
    </section>
</body>

</html>
