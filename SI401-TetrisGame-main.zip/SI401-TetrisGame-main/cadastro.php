<!DOCTYPE html>

<html lang="pt">

<head>
    <title>Cadastro | Mirror Tetris</title>

    <meta charset="UTF-8">

    <link rel="stylesheet" href="./css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
</head>

<body id="cadastro">
    <section class="cadastro">
        <h1>Crie sua conta</h1>

        <form class="formulario" action="jogo.php" method="POST" autocomplete="off"
            onsubmit="return validateRegisterForm()">
            <div class="flutuante">
                <input id="nome_completo" class="cadastro" type="text" name="nome_completo" placeholder="Nome completo"
                    required>
                <label for="nome_completo">Nome completo</label>
            </div>
            <div class="flutuante">
                <input id="data_nascimento" class="cadastro" type="date" name="data_nascimento" required>
                <label for="data_nascimento">Data de nascimento</label>
            </div>
            <div class="flutuante">
                <input id="cpf" class="cadastro" type="text" name="cpf" placeholder="CPF" required>
                <label for="cpf">CPF</label>
            </div>
            <div class="flutuante">
                <input id="telefone" class="cadastro" type="tel" name="telefone" placeholder="Telefone" required>
                <label for="telefone">Telefone</label>
            </div>
            <div class="flutuante">
                <input id="email" class="cadastro" type="email" name="email" placeholder="E-mail" required>
                <label for="email">E-mail</label>
            </div>
            <div class="flutuante">
                <input id="username" class="cadastro" type="text" name="username" placeholder="Username" required>
                <label for="username">Username</label>
            </div>
            <div class="flutuante">
                <input id="senha" class="cadastro" type="password" name="senha" placeholder="Senha" required>
                <label for="senha">Senha</label>
            </div>
            <div class="flutuante">
                <input id="confirmarsenha" class="cadastro" type="password" name="confirmarsenha" placeholder="Senha"
                    required>
                <label for="confirmarsenha">Confirmar senha</label>
            </div>

            <div id="alinhar">
                <button id="botaocadastro" type="submit" title="Cadastrar">Cadastre-se já!</button>
                <a id="botaovoltarlogin" href="login.php" title="Voltar">Voltar</a>
            </div>
        </form>

        <div class="logocadastro">
            <img class="logo" src="./images/logo-tetris.png" alt="logo_tetris">
        </div>
    </section>

    <script type="text/javascript" src="./js/form-validation.js"></script>
</body>

</html>