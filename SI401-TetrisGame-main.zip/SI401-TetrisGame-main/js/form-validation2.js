class Validate {

    static ValidateLoginForm() {
        
    }

    static ValidateRegisterForm() {

    }

    static ValidateEditUserInfoForm() {

    }
}