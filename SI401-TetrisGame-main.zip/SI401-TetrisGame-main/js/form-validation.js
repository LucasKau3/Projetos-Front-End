// Função para validar formulário de login
function validateLoginForm() {
    const usuario = document.getElementById("usuario").value;
    const senha = document.getElementById("senha").value;

    if (usuario.trim() === "" || senha.trim() === "") {
        alert("Por favor, preencha todos os campos.");
        return false;
    }

    // Aqui você pode adicionar lógica de validação adicional, se necessário.

    return true; // O formulário será enviado apenas se todos os campos estiverem preenchidos.
}

// Função para validar formulário de registro
function validateRegisterForm() {
    // Seleciona os campos de senha e confirmar senha
    const senha = document.getElementById("senha");
    const confirmarSenha = document.getElementById("confirmarsenha");

    // Verifica se as senhas não coincidem
    if (senha.value !== confirmarSenha.value) {
        alert("As senhas não coincidem. Por favor, verifique.");
        return false;
    }

    return true;
}

// Função para validar formulário de edição de infos do usuário
function validateEditUserInfoForm() {
    // Seleciona o formulário
    const formulario = document.querySelector(".formulario");

    // Seleciona os campos relevantes
    const nomeCompleto = document.getElementById("nome_completo");
    const telefone = document.getElementById("telefone");
    const email = document.getElementById("email");
    const novaSenha = document.getElementById("nova_senha");
    const confirmarNovaSenha = document.getElementById("confirmarnova_senha");

    // Variável para rastrear se algum campo foi modificado
    let algumCampoModificado = false;

    // Adicione ouvintes de evento para os campos relevantes
    nomeCompleto.addEventListener("input", marcaCampoModificado);
    telefone.addEventListener("input", marcaCampoModificado);
    email.addEventListener("input", marcaCampoModificado);
    novaSenha.addEventListener("input", marcaCampoModificado);
    confirmarNovaSenha.addEventListener("input", marcaCampoModificado);

    // Função para marcar um campo como modificado
    function marcaCampoModificado() {
        algumCampoModificado = true;
    }

    // Adiciona um ouvinte de evento para o envio do formulário
    formulario.addEventListener("submit", function (event) {
        // Verifica se pelo menos um campo foi modificado
        if (!algumCampoModificado) {
            alert("Nenhum campo foi modificado. Por favor, faça alguma alteração antes de enviar o formulário.");
            event.preventDefault(); // Impede o envio do formulário
        }

        // Verifica se a nova senha e a confirmação da nova senha coincidem
        if (novaSenha.value !== confirmarNovaSenha.value) {
            alert("A nova senha e a confirmação da nova senha não coincidem. Por favor, verifique.");
            event.preventDefault(); // Impede o envio do formulário
        }
    });
}