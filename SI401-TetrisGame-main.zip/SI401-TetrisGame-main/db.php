<?php
// Inicia conexão com o banco de dados
try {
    $conn = new PDO("mysql:host=localhost;dbname=myDB", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
// Se houver algum erro mostra uma mensagem de erro
catch(PDOException $e) {
    echo "A conexão falhou: " . $e->getMessage();
    }

// Verificando a conexão
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Definindo o conjunto de caracteres para utf8 (opcional)
$conn->set_charset("utf8");

// Agora, a variável $conn contém a conexão com o banco de dados,
// e você pode incluir este arquivo em outros scripts para usar a conexão.

// Lembre-se de fechar a conexão quando não for mais necessária.
// $conn->close();
?>
