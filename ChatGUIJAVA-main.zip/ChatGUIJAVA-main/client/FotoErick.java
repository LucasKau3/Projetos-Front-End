
import java.awt.*;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class FotoErick extends JPanel {
    private static final long serialVersionUID = 1L;

    public void paint(Graphics g) {
        super.paint(g);
        final Graphics2D auxGraphics = (Graphics2D) g;

        try {
            final URL ericImg = this.getClass().getResource(ConstantesGlobais.ericklImg);
            final Image aeImg = ImageIO.read(ericImg);
            auxGraphics.drawImage(aeImg, 20, 50, 180, 190, 0, 0, aeImg.getWidth(null), aeImg.getHeight(null), null);

        } catch (final IOException e) {
            System.out.println("Arquivo não encontrado " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Erro ao carregar arquivo " + e.getMessage());
        }
    }
}
