import java.awt.*;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class FotoPedro extends JPanel {
    private static final long serialVersionUID = 1L;

    public void paint(Graphics g) {
        super.paint(g);
        final Graphics2D auxGraphics = (Graphics2D) g;

        try {
            final URL pedroImg = this.getClass().getResource(ConstantesGlobais.pedroImg);
            final Image pImg = ImageIO.read(pedroImg);
            auxGraphics.drawImage(pImg, 20, 50, 180, 190, 0, 0, pImg.getWidth(null), pImg.getHeight(null), null);
        } catch (final IOException e) {
            System.out.println("Arquivo não encontrado " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Erro ao carregar arquivo " + e.getMessage());
        }
    }
}
