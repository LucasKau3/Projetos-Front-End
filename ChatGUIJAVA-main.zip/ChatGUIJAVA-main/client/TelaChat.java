// Tela CHATGUIJAVA - SI400. 

// Importação das bibliotecas.
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaChat extends JFrame {

    private JTextArea conversationArea;
    private JTextField messageField;
    private JButton sendButton;

    public TelaChat() {
        // Configuração da janela principal
        setTitle("TelaChat");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Componente JTextArea para exibir a conversação
        conversationArea = new JTextArea();
        conversationArea.setEditable(false); // Para impedir a edição do histórico
        JScrollPane scrollPane = new JScrollPane(conversationArea);

        // Configurar a política de rolagem
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Componente JTextField para entrada de mensagem
        messageField = new JTextField();
        messageField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensagem();
            }
        });

        // Botão de enviar mensagem
        sendButton = new JButton("Enviar");
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensagem();
            }

            // Verificação evitando que o usuário envie mensagem em branco.
            private void enviarMensagem() {
                String mensagem = messageField.getText().trim();
                if (!mensagem.isEmpty()) {
                    conversationArea.append("Você: " + mensagem + "\n");
                    messageField.setText("");
                } else {
                    // Mensagem de aviso para o usuário.
                    JOptionPane.showMessageDialog(null, "Não há uma mensagem para ser enviada.", "Aviso",
                            JOptionPane.WARNING_MESSAGE);
                }
            }

        });

        // Menu Arquivo
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("Arquivo");
        JMenuItem connectItem = new JMenuItem("Conexão");
        JMenuItem exitItem = new JMenuItem("Saída do Programa");

        connectItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirTelaConexao();
            }
        });

        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sairDoPrograma();
            }
        });

        fileMenu.add(connectItem);
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);

        // Menu Ajuda
        JMenu helpMenu = new JMenu("Ajuda");
        JMenuItem helpItem = new JMenuItem("Ajuda");
        JMenuItem aboutItem = new JMenuItem("Sobre");

        helpItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirJanelaAjuda();
            }
        });

        aboutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirJanelaSobre();
            }
        });

        helpMenu.add(helpItem);
        helpMenu.add(aboutItem);
        menuBar.add(helpMenu);

        // Configura a barra de menus na janela principal da tela.
        setJMenuBar(menuBar);

        // Layout para a entrada de mensagem e botão
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        // Adiciona os componentes ao contentPane
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(inputPanel, BorderLayout.SOUTH);
    }

    private void enviarMensagem() {
        String mensagem = messageField.getText();
        conversationArea.append("Você: " + mensagem + "\n");
        messageField.setText("");
    }

    private void abrirTelaConexao() {
        Conectar conectarDialog = new Conectar(this);
        conectarDialog.setVisible(true);
    }

    private void sairDoPrograma() {
        // Adicione a lógica para fechar conexões, salvar dados, etc., se necessário.
        System.exit(0);
    }

    private void abrirJanelaAjuda() {
        JTextArea text = new JTextArea(); // Inicializando o JTextArea.

        // Lógica para abrir a janela de Ajuda.
        String universidade = "Unicamp";
        String nome = "Grupo 06.";
        String faculdade = "Faculdade Tecnologia.";

        text.append("\n");
        text.append(
                nome + "\nPrograma desenvolvido como parte da Disciplina SI400 – Programação Orientada a Objetos II da "
                        + universidade + " na " + faculdade);
        text.append("\n");
        text.append("O projeto tem como objetivo criar um programa com a Graphical User Interface (GUI) para viabilizar"
                + " a conversação por texto (chat) entre duas máquinas.");

        // Utilizando JOptionPane para abertura do texto.
        JOptionPane.showMessageDialog(this, text, "Ajuda", JOptionPane.INFORMATION_MESSAGE);
    }

    private void abrirJanelaSobre() {
        System.out.println("Abrindo Janela Sobre");

        String nomeVersao = ConstantesGlobais.getNomeVersao();
        String textoSobre = ConstantesGlobais.getTextoSobre();

        System.out.println("Nome da Versão: " + nomeVersao);
        System.out.println("Texto Sobre: " + textoSobre);

        TelaSobre telaSobre = new TelaSobre(this, "Sobre - " + nomeVersao, textoSobre);
        telaSobre.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        telaSobre.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        telaSobre.setVisible(true);
    }

    public class Conectar extends JDialog {
        public Conectar(TelaChat telaChat) {
            this.setSize(200, 150);
            this.setLocationRelativeTo(null);

            JButton connect = new JButton("Conectar");
            connect.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Adicionar ação ao conectar, fechar e voltar à janela principal
                    // Fechar o JDialog
                    setVisible(false);
                }
            });

            // JLabel IP
            JLabel ip = new JLabel("IP: ");
            JTextField textIp = new JTextField(10);

            // JLabel Porta
            JLabel porta = new JLabel("Porta: ");
            JTextField textPorta = new JTextField(10);

            JPanel content = new JPanel();
            this.add(content);
            content.add(ip);
            content.add(textIp);
            content.add(porta);
            content.add(textPorta);
            content.add(connect);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TelaChat().setVisible(true);
            }
        });
    }
}
