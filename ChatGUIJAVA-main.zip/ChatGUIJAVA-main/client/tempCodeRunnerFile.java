
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class tempCodeRunnerFile extends JDialog implements ActionListener {
    private static final long serialVersionUID = 1L;
    private JButton botaoFecha;
    private JPanel painelTexto;
    private JPanel painelBotoes;
    private FotoErick imgErick;
    private FotoGino imgGino;
    private FotoLucas imgLucas;
    private FotoNathalia imgNathalia;
    private FotoPedro imgPedro;
    private final JTextArea conteudo;

    tempCodeRunnerFile(JFrame JanelaPrincipal, String titulo, String texto) throws HeadlessException {
        super(JanelaPrincipal, titulo);
        setSize(820, 500);
        setResizable(false);
        setLocationRelativeTo(JanelaPrincipal);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        this.botaoFecha = new JButton();
        this.painelTexto = new JPanel();
        this.painelBotoes = new JPanel();

        this.conteudo = new JTextArea();
        conteudo.setText(texto);
        formatTexto();

        painelTexto = new JPanel();
        painelTexto.setBackground(Color.white);
        painelTexto.setBorder(new TitledBorder(new LineBorder(Color.gray), ConstantesGlobais.creditos));
        painelTexto.add(conteudo);
        add(painelTexto, BorderLayout.WEST);

        JPanel painelImagens = new JPanel(new FlowLayout());
        painelImagens.setBackground(Color.white);

        imgErick = new FotoErick();
        imgErick.setPreferredSize(new Dimension(200, 200));
        imgErick.setBorder(new TitledBorder(new LineBorder(Color.gray), ConstantesGlobais.eric));
        imgErick.setBackground(Color.white);
        painelImagens.add(imgErick);

        imgGino = new FotoGino();
        imgGino.setPreferredSize(new Dimension(200, 200));
        imgGino.setBorder(new TitledBorder(new LineBorder(Color.gray), ConstantesGlobais.gino));
        imgGino.setBackground(Color.white);
        painelImagens.add(imgGino);

        imgLucas = new FotoLucas();
        imgLucas.setPreferredSize(new Dimension(200, 200));
        imgLucas.setBorder(new TitledBorder(new LineBorder(Color.gray), ConstantesGlobais.lucas));
        imgLucas.setBackground(Color.white);
        painelImagens.add(imgLucas);

        imgNathalia = new FotoNathalia();
        imgNathalia.setPreferredSize(new Dimension(200, 200));
        imgNathalia.setBorder(new TitledBorder(new LineBorder(Color.gray), ConstantesGlobais.nathalia));
        imgNathalia.setBackground(Color.white);
        painelImagens.add(imgNathalia);

        imgPedro = new FotoPedro();
        imgPedro.setPreferredSize(new Dimension(200, 200));
        imgPedro.setBorder(new TitledBorder(new LineBorder(Color.gray), ConstantesGlobais.pedro));
        imgPedro.setBackground(Color.white);
        painelImagens.add(imgPedro);

        add(painelImagens, BorderLayout.CENTER);

        painelBotoes = new JPanel();
        botaoFecha = new JButton("Fechar");
        botaoFecha.addActionListener(this);
        painelBotoes.add(botaoFecha);
        add(painelBotoes, BorderLayout.SOUTH);

    }

    private void formatTexto() {
        conteudo.setPreferredSize(new Dimension(100, 100));
        conteudo.setForeground(Color.BLACK);
        conteudo.setBackground(Color.white);
        conteudo.setEditable(false);
        conteudo.setFocusable(false);
        conteudo.setLineWrap(true);
        conteudo.setWrapStyleWord(true);

        conteudo.setFont(new Font("Arial", Font.BOLD, 12));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        this.setVisible(false);
    }
}