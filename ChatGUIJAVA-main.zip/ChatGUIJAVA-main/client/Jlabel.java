
public interface Jlabel {

}
