
public class Conectar {

    public void setVisible(boolean b) {
    }

}
