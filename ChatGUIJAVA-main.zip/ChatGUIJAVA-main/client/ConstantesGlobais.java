public class ConstantesGlobais {
    // Você pode adicionar essa pagina no JDialog Sobre
    public static final String creditos = "Créditos";
    public static final String autor = "Grupo a.06";
    public static final String universidade = "Universidade Estadual de Campinas";
    public static final String faculdade = "Faculdade de Tecnologia - FT";
    public static final String nome = "Projeto III: Conversação Online (Chat)";
    public static final String versao = "Versão 1.0";

    // nome participantes
    public static final String eric = "Eric Vitta Da Silva";
    public static final String gino = "Gino Carlo Graciano Grippo";
    public static final String lucas = "Lucas Kauê Pedralina Lobo";
    public static final String nathalia = "Nathalia V. Soares Rodrigues";
    public static final String pedro = "Pedro H. Dos Santos Varela";

    // Fotos participantes
    public static final String ericklImg = "ericklImg.jpeg";
    public static final String ginoImg = "ginoImg.jpeg";
    public static final String lucasImg = "lucasImg.jpeg";
    public static final String nathaliaImg = "nathaliaImg.jpeg";
    public static final String pedroImg = "pedroImg.jpeg";

    // Versão e créditos de autoria
    static String getTextoSobre() {
        final StringBuffer text = new StringBuffer();
        text.append("\n\n");
        text.append(versao);
        text.append("\n\n");
        text.append(autor);
        return (text.toString());
    }

    // Texto explicativo do programa
    static String getTextoAjuda() {
        StringBuilder text = new StringBuilder();

        text.append("\n");
        text.append(
                nome + "\nPrograma desenvolvido como parte da Disciplina SI400 – Programação Orientada a Objetos II da "
                        + universidade + " na " + faculdade);
        text.append("\n");
        text.append("O projeto tem como objetivo criar um programa com a Graphical User Interface (GUI) para viabilizar"
                + " a conversação por texto (chat) entre duas máquinas.");

        return (text.toString());
    }

    static String getNomeVersao() {
        // Projeto III: Conversação Online (Chat) - Versão 1.0
        return (nome + " - " + versao);
    }

    // Preciso de uma classe para cada figura???

}
