
public interface Jtextfield {

}
