# ChatGUIJAVA 
Desenvolvimento de um programa em Java com interface gráfica para realizar conversação por texto (chat).

Docs do projeto:
https://drive.google.com/drive/u/2/folders/1sSapGGdZQRusEIFB1eJGQcPKvu-Kl7Go

Projeto Tetris - Instruções de Instalação e Contribuição
Instalação Local
Siga estas etapas para instalar e executar o projeto em sua máquina local:

Clone o repositório:

git clone https://github.com/LucasKau3/ChatGUIJAVA.git
Navegue até o diretório do projeto:

cd ChatGUIJAVA

Modificando o Código
Para contribuir com o projeto e modificar o código, siga estas etapas:

Crie uma branch:
Antes de fazer qualquer modificação, crie uma nova branch com um nome descritivo para sua contribuição. Isso ajuda a manter o código principal do projeto limpo.

git checkout -b nome-da-sua-branch
Substitua nome-da-sua-branch por um nome que descreva a sua modificação.

Faça suas modificações:
Agora, faça as modificações que deseja no código, como adicionar recursos, corrigir bugs, ou qualquer outra melhoria.

Commit suas mudanças:
Após fazer as modificações, você deve commitá-las. Certifique-se de incluir uma mensagem de commit descritiva.

git commit -m "Adicionei novos recursos"
Envie sua branch para o Github:

Envie sua branch para o repositório remoto no Github.
git push origin nome-da-sua-branch

Crie um Pull Request:
Acesse a página do seu repositório no Github e clique na aba "Pull Requests". Em seguida, clique em "New Pull Request". Selecione sua branch como a branch de origem e a branch principal como a branch de destino. Descreva suas modificações e clique em "Create Pull Request".

Revisão e Merge:
Os colaboradores do projeto revisarão suas modificações e, se estiverem corretas e alinhadas com os objetivos do projeto, mesclarão suas alterações na branch principal.

Mantenha sua branch atualizada:
Certifique-se de manter sua branch atualizada com as últimas alterações da branch principal, especialmente se a revisão do Pull Request levar algum tempo.
git pull origin main
Lembre-se de que é importante seguir as diretrizes do projeto e contribuir de maneira construtiva. Obrigado por contribuir para o nosso projeto!

Nota: Certifique-se de que você tenha o Git instalado em seu sistema.



